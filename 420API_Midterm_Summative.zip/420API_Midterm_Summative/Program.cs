﻿using System.ComponentModel.Design;
using System.Diagnostics.Metrics;
using System.Numerics;

namespace _420API_Midterm_Summative
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string? name = null;
            string? description = null;
            int? partnumber = null;
            decimal? price = null;

            string? menu = null;

            while (menu != "Q")
            {
                Console.Clear();
                Console.WriteLine("** Hello There!! Welcome to A&P Online Computer Hardware Store **");
                Console.WriteLine("Please enter the choice of entry for your computer hardware component menu");
                Console.WriteLine("");

                if (name == null)
                {
                    Console.WriteLine("Please press A to enter the component name");
                }
                else
                {
                    Console.WriteLine("Please press A to edit the component name");
                }
                if (description == null)
                {
                    Console.WriteLine("Please press B to enter the component description");
                }
                else
                {
                    Console.WriteLine("Please press B to edit the component description");
                }
                if (partnumber == null)
                {
                    Console.WriteLine("Please press C to enter the part number");
                }
                else
                {
                    Console.WriteLine("Plese press C to edit the part number");
                }
                if (price == null)
                {
                    Console.WriteLine("Please press D to enter the retail price");
                }
                else
                {
                    Console.WriteLine("Please press D to edit the retail price");
                }
                Console.WriteLine("Please press E to display the Computer Hardware Component Data");
                Console.WriteLine("");
                Console.WriteLine("Please press Q if you would like to exit the program");
                Console.WriteLine("");
                Console.WriteLine("Please enter what you would like to do next: ");
                menu = Console.ReadLine();
                menu = menu?.ToUpper();
                Console.WriteLine("");

                if (menu != "A" && menu != "B" && menu != "C" && menu != "D" && menu != "E" && menu != "Q")
                {
                    Console.WriteLine("Invalid choice" + "," + "please enter a valid choice");
                    Console.WriteLine("Please press any key to try again");
                    _ = Console.ReadKey();
                }
                else
                {
                    if (menu == "A")
                    {
                        Console.WriteLine("Please enter the component name: ");
                        name = Console.ReadLine();
                        Console.WriteLine("Data successfully saved, Press any key to continue further");
                        _ = Console.ReadKey();
                    }
                    else if (menu == "B")
                    {
                        Console.WriteLine("Please enter the conponent description: ");
                        description = Console.ReadLine();
                        Console.WriteLine("Data successfully saved, Press any key to continue further");
                        _ = Console.ReadKey();
                    }
                    else if (menu == "C")
                    {

                        Console.WriteLine("Please enter the component part number: ");
                        string partString = Console.ReadLine();
                        partnumber = int.Parse(partString);
                        Console.WriteLine("Data saved successfully, Press any key to continue further");
                        _ = Console.ReadKey();
                    }
                    else if (menu == "D")
                    {
                        Console.WriteLine("Please enter the component retail price: ");
                        string priceString = Console.ReadLine();
                        price = decimal.Parse(priceString);
                        Console.WriteLine("Data saved successfully, Press any key to continue further");
                        _ = Console.ReadKey();
                    }
                    else if (menu == "E")
                    {
                        Console.WriteLine("Current component data: ");
                        Console.WriteLine("");
                        Console.WriteLine("Component Name: " + name);
                        Console.WriteLine("Component Descripiton: " + description);
                        Console.WriteLine("Component Part Number: " + partnumber);
                        Console.WriteLine("Component Retail Price: " + price);
                        Console.WriteLine("");
                        Console.WriteLine("Please press any key to continue further");
                        _ = Console.ReadKey();                          
                    }
                    
                    else
                    {
                        Console.WriteLine("The program will now end, Goodbye!!");
                        Console.WriteLine("Please press any key to exit the window");
                        _ = Console.ReadKey();
                    }
                }
            }
        }
    }
}